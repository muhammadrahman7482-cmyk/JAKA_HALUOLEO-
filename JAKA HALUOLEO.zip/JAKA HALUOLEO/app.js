const products = [
    {
        nama: "Akun Free Fire Sultan",
        harga: "Rp500.000"
    },
    {
        nama: "Akun Mobile Legends",
        harga: "Rp300.000"
    },
    {
        nama: "Akun Roblox",
        harga: "Rp150.000"
    }
];

const container = document.getElementById("product-list");

products.forEach(product => {

    container.innerHTML += `
        <div class="card">
            <h3>${product.nama}</h3>
            <p>${product.harga}</p>
            <button class="btn">
                Beli
            </button>
        </div>
    `;

});